package com.example.android.newsapp;

import android.content.Context;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class NewsLoader extends AsyncTaskLoader<List<News>> {

    public NewsLoader(Context context) {
        super(context);
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Override
    public List<News> loadInBackground() {
        List<News> listOfNews = null;
        try {
            URL url = NewsUtils.createUrl();
            String jsonResponse = NewsUtils.makeHttpRequest(url);
            listOfNews = NewsUtils.parseJson(jsonResponse);
        } catch (IOException e) {
            Log.e("Newsutils", "Error Loader LoadInBackground: ", e);
        }
        return listOfNews;
    }
}
